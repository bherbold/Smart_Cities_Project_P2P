def clearing_Price_allocation():
    return None